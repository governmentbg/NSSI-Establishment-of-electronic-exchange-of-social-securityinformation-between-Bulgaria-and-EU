﻿using Autofac;

namespace EventListener.Common
{
    public static class DIContainer
    {
        public static IContainer Container;
    }
}
