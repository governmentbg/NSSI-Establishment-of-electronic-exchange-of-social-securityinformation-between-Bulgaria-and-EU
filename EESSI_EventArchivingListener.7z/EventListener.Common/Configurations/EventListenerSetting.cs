﻿using EventListener.Common.Configurations.Elements;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventListener.Common.Configuration
{
    public class EventListenerSetting : ConfigurationSection
    {

        [ConfigurationProperty("WatcherSettingsList")]
        public WatcherSettingscollection WatcherSettingsList
        {
            get { return ((WatcherSettingscollection)(base["WatcherSettingsList"])); }
            set { base["WatcherSettingsList"] = value; }
        }

        [ConfigurationProperty("EventLogSettings", IsRequired = true)]
        public EventLogSetting EventLogSettings
        {
            get
            {
                return (EventLogSetting)this["EventLogSettings"];
            }
            set
            {
                value = (EventLogSetting)this["EventLogSettings"];
            }
        }

        [ConfigurationProperty("ServiceInstallerSettings", IsRequired = true)]
        public ServiceInstallerSetting ServiceInstallerSettings
        {
            get
            {
                return (ServiceInstallerSetting)this["ServiceInstallerSettings"];
            }
            set
            {
                value = (ServiceInstallerSetting)this["ServiceInstallerSettings"];
            }
        }

        public static EventListenerSetting EventListenerSettings
        {
            get
            {
                return ConfigurationManager.GetSection("EventListenerConfiguration") as EventListenerSetting;
            }
        }

    }
}
