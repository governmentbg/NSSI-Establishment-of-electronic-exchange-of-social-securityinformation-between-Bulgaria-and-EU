﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventListener.Common.Configurations.Elements
{
    public class EventLogSetting : ConfigurationElement
    {
        [ConfigurationProperty("eventLogSource", IsRequired = true)]
        public string EventLogSource
        {
            get
            {
                return (string)this["eventLogSource"];
            }
            set
            {
                value = (string)this["eventLogSource"];
            }
        }

        [ConfigurationProperty("eventLogName", IsRequired = true)]
        public string EventLogName
        {
            get
            {
                return (string)this["eventLogName"];
            }
            set
            {
                value = (string)this["eventLogName"];
            }
        }

        [ConfigurationProperty("maximumKilobytes", IsRequired = false, DefaultValue = (long)200000)]
        public long MaximumKilobytes
        {
            get
            {
                return (long)this["maximumKilobytes"];
            }
            set
            {
                value = (long)this["maximumKilobytes"];
            }
        }

    }
}
