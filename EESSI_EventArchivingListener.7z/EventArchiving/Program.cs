﻿using EventListener.Common.Configuration;
using EventListener.Common.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace EventArchiving
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        static void Main(string[] args)
        {
            DIHelper.SetDIContainer();

            EventListenerSetting eventListenerConfiguration = EventListenerSetting.EventListenerSettings;

            if (Environment.UserInteractive)
            {
                FileMonitoring fileMonitoring = new FileMonitoring(eventListenerConfiguration);
                fileMonitoring.StartupAndStop(args);
            }
            else
            {
                ServiceBase[] ServicesToRun = new ServiceBase[]
                {
                    new FileMonitoring(eventListenerConfiguration)
                };
                ServiceBase.Run(ServicesToRun);
            }
        }
    }
}
