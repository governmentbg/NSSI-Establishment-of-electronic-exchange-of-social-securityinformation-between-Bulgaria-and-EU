﻿using EventListener.Common.Helpers;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration.Install;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.ServiceProcess;
using System.ServiceProcess.Design;

namespace EventArchiving
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        // get installation path
        public string InstalatinDirectory => Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);


        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.serviceProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.serviceInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // serviceProcessInstaller
            // 
            this.serviceProcessInstaller.Account = System.ServiceProcess.ServiceAccount.User;
            this.serviceProcessInstaller.Password = null;
            this.serviceProcessInstaller.Username = null;
            // 
            // serviceInstaller
            // 
            this.serviceInstaller.Description = "Rina Archiving processor - listening for incoming archiving";
            this.serviceInstaller.DisplayName = "TL EESSI Archiving Processor";
            this.serviceInstaller.ServiceName = "TL EESSI Archiving Processor";
            this.serviceInstaller.StartType = System.ServiceProcess.ServiceStartMode.Automatic;
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.serviceProcessInstaller,
            this.serviceInstaller});

            this.BeforeInstall += new InstallEventHandler(this.ProjectInstaller_BeforeInstall);
            this.AfterInstall += new InstallEventHandler(this.ProjectInstaller_AfterInstall);
            this.AfterUninstall += new InstallEventHandler(this.ProjectInstaller_AfterUninstall);
        }

        public override void Install(IDictionary stateSaver)
        {
            using (ServiceInstallerDialog dlg = new ServiceInstallerDialog())
            {
                dlg.ShowDialog();

                switch (dlg.Result)
                {
                    case ServiceInstallerDialogResult.Canceled:
                        throw new InvalidOperationException("Installation is canceled.");
                    case ServiceInstallerDialogResult.UseSystem:
                        this.serviceProcessInstaller.Account = ServiceAccount.LocalSystem;
                        break;
                    case ServiceInstallerDialogResult.OK:
                        if (string.IsNullOrEmpty(dlg.Username) && string.IsNullOrEmpty(dlg.Password))
                        {
                            this.serviceProcessInstaller.Account = ServiceAccount.LocalSystem;
                        }
                        else
                        {
                            this.serviceProcessInstaller.Username = dlg.Username;
                            this.serviceProcessInstaller.Password = string.IsNullOrEmpty(dlg.Password) ? null : dlg.Password;
                        }
                        break;
                }
            }

            serviceProcessInstaller
              .GetType()
              .GetField("haveLoginInfo", BindingFlags.Instance | BindingFlags.NonPublic)
              .SetValue(serviceProcessInstaller, true);

            base.Install(stateSaver);
        }

        private void ProjectInstaller_AfterUninstall(object sender, InstallEventArgs e)
        {
            try
            {
                int exitCode;

                using (var process = new Process())
                {
                    var startInfo = process.StartInfo;
                    startInfo.FileName = "sc";
                    startInfo.WindowStyle = ProcessWindowStyle.Hidden;

                    // tell Windows that the service should restart if it fails
                    startInfo.Arguments = string.Format($"delete {serviceInstaller.ServiceName}");

                    process.Start();
                    process.WaitForExit();

                    exitCode = process.ExitCode;
                }

                Directory.Delete(InstalatinDirectory, true);
            }
            catch
            {
            }
        }


        private void ProjectInstaller_AfterInstall(object sender, InstallEventArgs e)
        {
            if (!string.IsNullOrEmpty(serviceProcessInstaller.Username))
                FileOperationHelper.SetPartialAccess(InstalatinDirectory, serviceProcessInstaller.Username);
        }


        #endregion

        private void ProjectInstaller_BeforeInstall(object sender, InstallEventArgs e)
        {
            FileOperationHelper.CreateEventLog("EESSI_EventArchivingListener", "EESSI_EventArchivingListener_Log",200000);

            List<ServiceController> services = new List<ServiceController>(ServiceController.GetServices());

            var service = services.FirstOrDefault(x => x.ServiceName == serviceInstaller.ServiceName);

            if (service != null)
            {
                if (service.Status == ServiceControllerStatus.Running)
                {
                    service.Stop();
                }

                ServiceInstaller ServiceInstallerObj = new ServiceInstaller();
                ServiceInstallerObj.Context = new System.Configuration.Install.InstallContext();
                ServiceInstallerObj.Context = Context;
                ServiceInstallerObj.ServiceName = this.serviceInstaller.ServiceName;
                ServiceInstallerObj.Uninstall(null);

                //DeleteEventLog();
            }
        }

        private void DeleteEventLog()
        {
            try
            {
                FileOperationHelper.DeleteEventLog("EESSI_EventArchivingListener", "EESSI_EventArchivingListener_Log");
            }
            catch { }
        }

        private System.ServiceProcess.ServiceProcessInstaller serviceProcessInstaller;
        private System.ServiceProcess.ServiceInstaller serviceInstaller;
    }
}