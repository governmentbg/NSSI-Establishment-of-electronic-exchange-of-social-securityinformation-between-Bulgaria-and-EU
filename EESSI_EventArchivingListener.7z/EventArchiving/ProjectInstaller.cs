﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.Threading.Tasks;

namespace EventArchiving
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : System.Configuration.Install.Installer
    {
        //#if DEBUG
        //int processId = Process.GetCurrentProcess().Id;
        //string message = string.Format("Please attach the debugger to process [{0}].", processId);
        //MessageBox.Show(message, "Debug");
        //#endif

        public ProjectInstaller()
        {
            InitializeComponent();
        }
    }
}
