﻿using Autofac;
using EventListener.Common;
using EventProcessor.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventProcessor
{
    public static class EventProcessorResolver
    {
        public static  IEventProcessor Resolve(string key)
        {
            IEventProcessor result = null;
            switch(key)
            {
                case "CaseWatcherSettings":
                    
                    ICaseEventProcessor caseProcessor = DIContainer.Container.Resolve<ICaseEventProcessor>();
                    result = caseProcessor;
                    break;

                case "DocumentWatcherSettings":
                    IDocumentEventProcessor docProcessor = DIContainer.Container.Resolve<IDocumentEventProcessor>();
                    result = docProcessor;
                    break;

                case "ArchivingWatcherSettings":
                    IArchivingEventProcessor archivingProcessor = DIContainer.Container.Resolve<IArchivingEventProcessor>();
                    result = archivingProcessor;
                    break;
            }

            return result;
        }
    }
}
